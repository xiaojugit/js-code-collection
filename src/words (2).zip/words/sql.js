var mysql = require('mysql');
let fs = require("fs");

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: '3306',
    database: 'test'
});

connection.connect(function(err) {
    if (err) {
        console.error('error connecting: ' + err.stack);
        return;
    }
    console.log('connected as id ' + connection.threadId);
});

let index = 0;
let arrPath = [
    './txt/2words_new.txt',
    './txt/2words_proofread.txt',
    './txt/3words_new.txt',
    './txt/3words_proofread.txt',
    './txt/4words_new.txt',
    './txt/4words_proofread.txt',
    './txt/5words.txt',
    './txt/6words.txt',
    './txt/7words.txt',
    './txt/8words.txt'
];

function insertWords(values) {
    var sql = 'INSERT INTO words(word) VALUES ' + values;
    // INSERT INTO words(word) VALUES ("阿尔巴尼亚"), ("阿尔卑斯山"), ("阿尔及利亚"),
    /* 
    DROP TABLE IF EXISTS `words`;
    CREATE TABLE `words` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `word` char(20) NOT NULL DEFAULT '' COMMENT '中文词语',
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
     */
    connection.query(sql, function(err, result) {
        if (err) {
            console.log('[INSERT INTO ERROR] - ', err.message);
            return;
        }
        console.log('--------------------------INSERT INTO----------------------------');
        console.log(result);
        console.log('------------------------------------------------------------\n\n');
        ++index;
        if (index > arrPath.length - 1) {
            connection.end();
        } else {
            proofreadFile(arrPath[index]);
        }
    });
}

function proofreadFile(readPath) {
    fs.readFile(readPath, 'utf8', function(err, data) {
        if (!err) {
            let text = '';
            let arr = data.split('\n');
            for (let i = 0; i < arr.length; i++) {
                if (arr[i] && arr[i].length > 1) {
                    if (i === arr.length - 2) {
                        text += '("' + arr[i] + '")';
                    } else {
                        text += '("' + arr[i] + '"), ';
                    }
                }
            }
            // console.log(text);
            insertWords(text);
            // fs.writeFile('insert.sql', 'INSERT INTO `words` (`word`) VALUES ' + text, (err) => {
            //     if (err) {
            //         console.error(err);
            //     } else {
            //         console.log('写入成功');
            //     }
            // });
        } else {
            console.log(err);
        }
    });
}

proofreadFile(arrPath[index]);