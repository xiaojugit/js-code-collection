let cheerio = require('cheerio');
let fs = require("fs");

let idx = 1;

function getFile(readPath, writePath) {
    fs.readFile(readPath, function(err, data) {
        if (!err) {
            let $ = cheerio.load(data);
            let text = '';
            $('.reader-word-layer').each(function(element) {
                var word = $(this).text().trim();
                if (word !== '' && !(word > 0)) {
                    text += word + '\n';
                }
            });

            // writeFile
            fs.appendFile(writePath, text, (err) => {
                if (err) {
                    console.error(err);
                } else {
                    console.log('写入成功', idx);
                    ++idx;
                    if (idx < 10) {
                        getFile('./html/0' + idx + '.html', './txt/2words.txt');
                    } else if (idx < 37) {
                        getFile('./html/' + idx + '.html', './txt/2words.txt');
                    } else if (idx < 49) {
                        getFile('./html/' + idx + '.html', './txt/3words.txt');
                    } else if (idx < 77) {
                        getFile('./html/' + idx + '.html', './txt/4words.txt');
                    } else if (idx < 79) {
                        getFile('./html/' + idx + '.html', './txt/5words.txt');
                    } else if (idx < 80) {
                        getFile('./html/' + idx + '.html', './txt/6words.txt');
                    } else if (idx < 81) {
                        getFile('./html/' + idx + '.html', './txt/7words.txt');
                    } else if (idx < 82) {
                        getFile('./html/' + idx + '.html', './txt/8words.txt');
                    } else if (idx < 83) {
                        getFile('./html/' + idx + '.html', './txt/9words.txt');
                    } else if (idx < 84) {
                        getFile('./html/' + idx + '.html', './txt/new-words.txt');
                    }
                }
            });
        } else {
            console.log(err);
        }
    });
}

getFile('./html/01.html', './txt/2words.txt');