let mysql = require('mysql');
let fs = require("fs");

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: '3306',
    database: 'test'
});

connection.connect(function(err) {
    if (err) {
        console.error('error connecting: ' + err.stack);
        return;
    }
    console.log('connected as id ' + connection.threadId);
});

function randWords(num) {
    let sql = 'SELECT word FROM `words` ORDER BY RAND() LIMIT ' + num + ';';

    connection.query(sql, function(err, result) {
        if (err) {
            console.log('[SELECT ERROR] - ', err.message);
            return;
        }
        console.log('--------------------------SELECT----------------------------');
        console.log(result);
        console.log('------------------------------------------------------------\n');

        let wordsArr = [];
        for (let i = 0; i < num; i++) {
            wordsArr.push(result[i].word);
        }
        console.log(wordsArr.join('    '));
        connection.end();
    });
}

randWords(5)