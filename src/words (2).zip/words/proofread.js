let fs = require("fs");
let readLine = require('readline');

let idx = 2;

function proofreadFile(readPath, writePath) {
    fs.readFile(readPath, 'utf8', function(err, data) {
        if (!err) {
            let text = '';
            let text2 = '';
            let arr = data.split('\n');
            for (let i = 0; i < arr.length; i++) {
                // if (arr[i] && arr[i].length < idx) {
                //     text += arr[i];
                // }
                if (arr[i] && arr[i].length == idx) {
                    text += arr[i] + '\n';
                }
            }
            // for (let i = 0; i < text.length; i++) {
            //     if ((i + 1) % idx === 0) {
            //         text2 += text[i] + '\n';
            //     } else {
            //         text2 += text[i];
            //     }
            // }
            // console.log(text);
            // writeFile
            fs.writeFile(writePath, text, (err) => {
                if (err) {
                    console.error(err);
                } else {
                    console.log('写入成功', idx);
                    ++idx;
                    if (idx < 5) {
                        // proofreadFile('./txt/' + idx + 'words.txt', './txt/' + idx + 'words_proofread.txt');
                        proofreadFile('./txt/' + idx + 'words.txt', './txt/' + idx + 'words_new.txt');
                    }
                }
            });
        } else {
            console.log(err);
        }
    });
}

proofreadFile('./txt/2words.txt', './txt/2words_new.txt');